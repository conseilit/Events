--==============================================================================
--
--  Summary:  PASS Summit 2022
--  Date:     11/2022
--
--  ----------------------------------------------------------------------------
--  Written by Christophe LAPORTE, SQL Server MVP / MCM
--	Twitter : @ConseilIT
--  
--  You may alter this code for your own *non-commercial* purposes. You may
--  republish altered code as long as you give due credit.
--  
--  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
--  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
--  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
--  PARTICULAR PURPOSE.
--==============================================================================


USE [Pass2022]
GO

SELECT *
INTO TestTable
FROM AdventureWorks2017.Sales.SalesOrderDetail;
GO

CREATE CLUSTERED INDEX NCI_TestTable_SalesOrderDetailID
ON TestTable(SalesOrderDetailID);
GO

-- Lock escalation occurs when dealing with 5000+ rows
BEGIN TRAN
	UPDATE TestTable 
	SET ProductID = ProductID
	WHERE SalesOrderDetailID <= 7000;
	
	SELECT COUNT(*) as Locks
	FROM sys.dm_tran_locks
	WHERE request_session_id = @@SPID;
	
	SELECT COUNT(*) as Locks,resource_type
	FROM sys.dm_tran_locks
	WHERE request_session_id = @@SPID
	GROUP BY resource_type;
	
	SELECT resource_type,db_name(resource_database_id) as DatabaseName,
		    CASE resource_type
			 WHEN 'KEY' THEN  
				( SELECT CONCAT('Table ',object_name(object_id),' / KeyHashValue ',SUBSTRING(resource_description,2,LEN(resource_description)-2))
					FROM sys.dm_db_partition_stats
					WHERE partition_id= resource_associated_entity_id
				)
			 WHEN 'PAGE' THEN  
				( SELECT CONCAT('Table ',object_name(object_id),' / Page ', SUBSTRING(resource_description,CHARINDEX(':',resource_description)+1,LEN(resource_description)))
					FROM sys.dm_db_partition_stats
					WHERE partition_id= resource_associated_entity_id
				)
			 WHEN 'HOBT' THEN  
				( SELECT CONCAT('Table ',object_name(ps.object_id),' / PartitionID ', p.partition_id)
					FROM sys.dm_db_partition_stats ps
					INNER JOIN sys.partitions p ON p.object_id = ps.object_id and p.partition_id = ps.partition_id
					WHERE ps.partition_id= resource_associated_entity_id
				)
			 WHEN 'DATABASE' THEN  
				( SELECT CONCAT('Database ',db_name(resource_database_id))
				)
			 ELSE CONCAT('Table ',object_name(resource_associated_entity_id))
			END	 AS [Resource],
	       request_type,request_mode,request_status, request_session_id 
	FROM sys.dm_tran_locks
	WHERE request_session_id = @@SPID
	ORDER BY resource_type

ROLLBACK


-- Unless we disable the lock promotion
ALTER TABLE TestTable SET (LOCK_ESCALATION = DISABLE);

BEGIN TRAN
	UPDATE TestTable 
	SET ProductID = ProductID
	WHERE SalesOrderDetailID <= 7000;
	
	SELECT COUNT(*) as Locks
	FROM sys.dm_tran_locks
	WHERE request_session_id = @@SPID;
	
	SELECT COUNT(*) as Locks,resource_type
	FROM sys.dm_tran_locks
	WHERE request_session_id = @@SPID
	GROUP BY resource_type;
	
	SELECT resource_type,db_name(resource_database_id) as DatabaseName,
		    CASE resource_type
			 WHEN 'KEY' THEN  
				( SELECT CONCAT('Table ',object_name(object_id),' / KeyHashValue ',SUBSTRING(resource_description,2,LEN(resource_description)-2))
					FROM sys.dm_db_partition_stats
					WHERE partition_id= resource_associated_entity_id
				)
			 WHEN 'PAGE' THEN  
				( SELECT CONCAT('Table ',object_name(object_id),' / Page ', SUBSTRING(resource_description,CHARINDEX(':',resource_description)+1,LEN(resource_description)))
					FROM sys.dm_db_partition_stats
					WHERE partition_id= resource_associated_entity_id
				)
			 WHEN 'HOBT' THEN  
				( SELECT CONCAT('Table ',object_name(ps.object_id),' / PartitionID ', p.partition_id)
					FROM sys.dm_db_partition_stats ps
					INNER JOIN sys.partitions p ON p.object_id = ps.object_id and p.partition_id = ps.partition_id
					WHERE ps.partition_id= resource_associated_entity_id
				)
			 WHEN 'DATABASE' THEN  
				( SELECT CONCAT('Database ',db_name(resource_database_id))
				)
			 ELSE CONCAT('Table ',object_name(resource_associated_entity_id))
			END	 AS [Resource],
	       request_type,request_mode,request_status, request_session_id 
	FROM sys.dm_tran_locks
	WHERE request_session_id = @@SPID
	ORDER BY resource_type

ROLLBACK

-- Back to default
ALTER TABLE TestTable SET (LOCK_ESCALATION = TABLE);



-- Unless another session already owns locks

-- Session #1
BEGIN TRAN
	UPDATE TestTable 
	SET ProductID = ProductID
	WHERE SalesOrderDetailID  between 2000 and 5000;
	
	SELECT COUNT(*) as Locks
	FROM sys.dm_tran_locks
	WHERE request_session_id = @@SPID;
	
	SELECT COUNT(*) as Locks,resource_type
	FROM sys.dm_tran_locks
	WHERE request_session_id = @@SPID
	GROUP BY resource_type;
	
	SELECT resource_type,db_name(resource_database_id) as DatabaseName,
		    CASE resource_type
			 WHEN 'KEY' THEN  
				( SELECT CONCAT('Table ',object_name(object_id),' / KeyHashValue ',SUBSTRING(resource_description,2,LEN(resource_description)-2))
					FROM sys.dm_db_partition_stats
					WHERE partition_id= resource_associated_entity_id
				)
			 WHEN 'PAGE' THEN  
				( SELECT CONCAT('Table ',object_name(object_id),' / Page ', SUBSTRING(resource_description,CHARINDEX(':',resource_description)+1,LEN(resource_description)))
					FROM sys.dm_db_partition_stats
					WHERE partition_id= resource_associated_entity_id
				)
			 WHEN 'HOBT' THEN  
				( SELECT CONCAT('Table ',object_name(ps.object_id),' / PartitionID ', p.partition_id)
					FROM sys.dm_db_partition_stats ps
					INNER JOIN sys.partitions p ON p.object_id = ps.object_id and p.partition_id = ps.partition_id
					WHERE ps.partition_id= resource_associated_entity_id
				)
			 WHEN 'DATABASE' THEN  
				( SELECT CONCAT('Database ',db_name(resource_database_id))
				)
			 ELSE CONCAT('Table ',object_name(resource_associated_entity_id))
			END	 AS [Resource],
	       request_type,request_mode,request_status, request_session_id 
	FROM sys.dm_tran_locks
	WHERE request_session_id = @@SPID
	ORDER BY resource_type

-- ROLLBACK


-- Session #2
BEGIN TRAN
	UPDATE TestTable 
	SET ProductID = ProductID
	WHERE SalesOrderDetailID between 12000 and 19000;
	
	SELECT COUNT(*) as Locks
	FROM sys.dm_tran_locks
	WHERE request_session_id = @@SPID;
	
	SELECT COUNT(*) as Locks,resource_type
	FROM sys.dm_tran_locks
	WHERE request_session_id = @@SPID
	GROUP BY resource_type;
	
	
	SELECT resource_type,db_name(resource_database_id) as DatabaseName,
		    CASE resource_type
			 WHEN 'KEY' THEN  
				( SELECT CONCAT('Table ',object_name(object_id),' / KeyHashValue ',SUBSTRING(resource_description,2,LEN(resource_description)-2))
					FROM sys.dm_db_partition_stats
					WHERE partition_id= resource_associated_entity_id
				)
			 WHEN 'PAGE' THEN  
				( SELECT CONCAT('Table ',object_name(object_id),' / Page ', SUBSTRING(resource_description,CHARINDEX(':',resource_description)+1,LEN(resource_description)))
					FROM sys.dm_db_partition_stats
					WHERE partition_id= resource_associated_entity_id
				)
			 WHEN 'HOBT' THEN  
				( SELECT CONCAT('Table ',object_name(ps.object_id),' / PartitionID ', p.partition_id)
					FROM sys.dm_db_partition_stats ps
					INNER JOIN sys.partitions p ON p.object_id = ps.object_id and p.partition_id = ps.partition_id
					WHERE ps.partition_id= resource_associated_entity_id
				)
			 WHEN 'DATABASE' THEN  
				( SELECT CONCAT('Database ',db_name(resource_database_id))
				)
			 ELSE CONCAT('Table ',object_name(resource_associated_entity_id))
			END	 AS [Resource],
	       request_type,request_mode,request_status, request_session_id 
	FROM sys.dm_tran_locks
	WHERE request_session_id = @@SPID
	ORDER BY resource_type

--ROLLBACK



-- What about partitioned tables ?

CREATE PARTITION FUNCTION [fn_Partition](int) 
AS RANGE RIGHT FOR VALUES (N'10000', N'20000', N'30000', N'40000', N'50000');
GO

CREATE PARTITION SCHEME [sch_partition] 
AS PARTITION [fn_Partition] TO ([PRIMARY], [PRIMARY], [PRIMARY], 
								[PRIMARY], [PRIMARY], [PRIMARY]);
GO

DROP INDEX NCI_TestTable_SalesOrderDetailID 
	ON [dbo].[TestTable];
GO

CREATE CLUSTERED INDEX [CIX_TestTable_SalesOrderDetailID] 
ON [dbo].[TestTable] 
(
	SalesOrderDetailID
) ON [sch_partition]([SalesOrderDetailID]);
GO


-- Show partitions
SELECT OBJECT_NAME(i.object_id) as Object_Name,
i.index_id,
        p.partition_number, fg.name AS Filegroup_Name, rows, au.total_pages,
        CASE boundary_value_on_right
                   WHEN 1 THEN 'less than'
                   ELSE 'less than or equal to' END as 'comparison', value
FROM sys.partitions p JOIN sys.indexes i
     ON p.object_id = i.object_id and p.index_id = i.index_id
       JOIN sys.partition_schemes ps
                ON ps.data_space_id = i.data_space_id
       JOIN sys.partition_functions f
                   ON f.function_id = ps.function_id
       LEFT JOIN sys.partition_range_values rv
ON f.function_id = rv.function_id
                    AND p.partition_number = rv.boundary_id
     JOIN sys.destination_data_spaces dds
             ON dds.partition_scheme_id = ps.data_space_id
                  AND dds.destination_id = p.partition_number
     JOIN sys.filegroups fg
                ON dds.data_space_id = fg.data_space_id
     JOIN (SELECT container_id, sum(total_pages) as total_pages
                     FROM sys.allocation_units
                     GROUP BY container_id) AS au
                ON au.container_id = p.partition_id
WHERE i.index_id <2
ORDER BY p.partition_number



-- By default, no change in lock escalation
-- But we can change this behavior
ALTER TABLE TestTable SET (LOCK_ESCALATION = AUTO);

SELECT name, lock_escalation_desc 
FROM sys.tables 
WHERE name = 'TestTable';

-- Session #1
BEGIN TRAN
	UPDATE TestTable 
	SET ProductID = ProductID
	WHERE SalesOrderDetailID <= 7000; 

	SELECT COUNT(*) as Locks
	FROM sys.dm_tran_locks
	WHERE request_session_id = @@SPID;
	
	SELECT COUNT(*) as Locks,resource_type
	FROM sys.dm_tran_locks
	WHERE request_session_id = @@SPID
	GROUP BY resource_type;

	
	SELECT resource_type,db_name(resource_database_id) as DatabaseName,
		    CASE resource_type
			 WHEN 'KEY' THEN  
				( SELECT CONCAT('Table ',object_name(object_id),' / KeyHashValue ',SUBSTRING(resource_description,2,LEN(resource_description)-2))
					FROM sys.dm_db_partition_stats
					WHERE partition_id= resource_associated_entity_id
				)
			 WHEN 'PAGE' THEN  
				( SELECT CONCAT('Table ',object_name(object_id),' / Page ', SUBSTRING(resource_description,CHARINDEX(':',resource_description)+1,LEN(resource_description)))
					FROM sys.dm_db_partition_stats
					WHERE partition_id= resource_associated_entity_id
				)
			 WHEN 'HOBT' THEN  
				( SELECT CONCAT('Table ',object_name(ps.object_id),' / PartitionID ', p.partition_id)
					FROM sys.dm_db_partition_stats ps
					INNER JOIN sys.partitions p ON p.object_id = ps.object_id and p.partition_id = ps.partition_id
					WHERE ps.partition_id= resource_associated_entity_id
				)
			 WHEN 'DATABASE' THEN  
				( SELECT CONCAT('Database ',db_name(resource_database_id))
				)
			 ELSE CONCAT('Table ',object_name(resource_associated_entity_id))
			END	 AS [Resource],
	       request_type,request_mode,request_status, request_session_id 
	FROM sys.dm_tran_locks
	WHERE request_session_id = @@SPID;
	GO
	
	
	SELECT [partition_id], [object_id], [index_id], [partition_number]
	FROM sys.partitions WHERE object_id = OBJECT_ID ('TestTable');
	
--ROLLBACK



-- Session #2
BEGIN TRAN
	UPDATE TestTable 
	SET ProductID = ProductID
	WHERE SalesOrderDetailID between 12000 and 19000;

	
	SELECT COUNT(*) as Locks
	FROM sys.dm_tran_locks
	WHERE request_session_id = @@SPID;
	
	SELECT COUNT(*) as Locks,resource_type
	FROM sys.dm_tran_locks
	WHERE request_session_id = @@SPID
	GROUP BY resource_type;

	SELECT resource_type,db_name(resource_database_id) as DatabaseName,
		    CASE resource_type
			 WHEN 'KEY' THEN  
				( SELECT CONCAT('Table ',object_name(object_id),' / KeyHashValue ',SUBSTRING(resource_description,2,LEN(resource_description)-2))
					FROM sys.dm_db_partition_stats
					WHERE partition_id= resource_associated_entity_id
				)
			 WHEN 'PAGE' THEN  
				( SELECT CONCAT('Table ',object_name(object_id),' / Page ', SUBSTRING(resource_description,CHARINDEX(':',resource_description)+1,LEN(resource_description)))
					FROM sys.dm_db_partition_stats
					WHERE partition_id= resource_associated_entity_id
				)
			 WHEN 'HOBT' THEN  
				( SELECT CONCAT('Table ',object_name(ps.object_id),' / PartitionID ', p.partition_id)
					FROM sys.dm_db_partition_stats ps
					INNER JOIN sys.partitions p ON p.object_id = ps.object_id and p.partition_id = ps.partition_id
					WHERE ps.partition_id= resource_associated_entity_id
				)
			 WHEN 'DATABASE' THEN  
				( SELECT CONCAT('Database ',db_name(resource_database_id))
				)
			 ELSE CONCAT('Table ',object_name(resource_associated_entity_id))
			END	 AS [Resource],
	       request_type,request_mode,request_status, request_session_id 
	FROM sys.dm_tran_locks
	WHERE request_session_id = @@SPID;
	GO
	
	SELECT [partition_id], [object_id], [index_id], [partition_number]
	FROM sys.partitions WHERE object_id = OBJECT_ID ('TestTable');
	
	
--ROLLBACK


-- Lock escalation attempts
SELECT OBJECT_NAME(ios.object_id) AS table_name
	,i.name AS index_name, ios.partition_number
	,ios.index_lock_promotion_attempt_count
	,ios.index_lock_promotion_count
FROM sys.dm_db_index_operational_stats(DB_ID(),OBJECT_ID('dbo.TestTable'),NULL,NULL) ios
INNER JOIN sys.indexes i ON i.object_id = ios.object_id AND i.index_id = ios.index_id
ORDER BY ios.range_scan_count DESC


