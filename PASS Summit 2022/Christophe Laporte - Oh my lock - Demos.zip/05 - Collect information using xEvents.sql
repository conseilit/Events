--==============================================================================
--
--  Summary:  PASS Summit 2022
--  Date:     11/2022
--
--  ----------------------------------------------------------------------------
--  Written by Christophe LAPORTE, SQL Server MVP / MCM
--	Twitter : @ConseilIT
--  
--  You may alter this code for your own *non-commercial* purposes. You may
--  republish altered code as long as you give due credit.
--  
--  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
--  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
--  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
--  PARTICULAR PURPOSE.
--==============================================================================

-- Enable blocked process event detection
EXEC sys.sp_configure N'show advanced options', N'1'
GO
RECONFIGURE WITH OVERRIDE
GO
EXEC sys.sp_configure N'blocked process threshold (s)', N'5'
GO
RECONFIGURE WITH OVERRIDE
GO


-- Create an xEvent to capture the blocked process sceanrio
CREATE EVENT SESSION [LockingIssues] ON SERVER 
ADD EVENT sqlserver.blocked_process_report(
    ACTION(sqlserver.client_app_name,sqlserver.client_hostname,sqlserver.database_id,sqlserver.database_name,sqlserver.query_hash,sqlserver.session_id,sqlserver.sql_text,sqlserver.username)),
ADD EVENT sqlserver.xml_deadlock_report(
    ACTION(sqlserver.client_app_name,sqlserver.client_hostname,sqlserver.database_id,sqlserver.database_name,sqlserver.query_hash,sqlserver.session_id,sqlserver.sql_text,sqlserver.username))
ADD TARGET package0.event_file(SET filename=N'LockingIssues',max_file_size=(50),max_rollover_files=(10))
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=ON,STARTUP_STATE=ON)
GO

ALTER EVENT SESSION [LockingIssues]
ON SERVER  
STATE = START;
GO



USE [Pass2022]
GO

-- Session #1
BEGIN TRAN Transaction1
	UPDATE Person
	SET Filler = 'Update BusinessEntityID 1 from Session 1'
	WHERE BusinessEntityID = 1;



-- Session #2
BEGIN TRAN Transaction2
	UPDATE Person
	SET Filler = 'Update BusinessEntityID 2 from Session 2'
	WHERE BusinessEntityID = 2;


-- Session #1
	UPDATE Person
	SET Filler = 'Update BusinessEntityID 2 from Session 1'
	WHERE BusinessEntityID = 2;



-- Session #2
	UPDATE Person
	SET Filler = 'Update BusinessEntityID 1 from Session 2'
	WHERE BusinessEntityID = 1;

