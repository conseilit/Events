--==============================================================================
--
--  Summary:  PASS Summit 2022
--  Date:     11/2022
--
--  ----------------------------------------------------------------------------
--  Written by Christophe LAPORTE, SQL Server MVP / MCM
--	Twitter : @ConseilIT
--  
--  You may alter this code for your own *non-commercial* purposes. You may
--  republish altered code as long as you give due credit.
--  
--  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
--  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
--  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
--  PARTICULAR PURPOSE.
--==============================================================================

-- Session #1 : Blocking session
COMMIT TRAN BlockingTransaction
GO

SELECT * FROM sys.dm_exec_session_wait_stats 
WHERE session_id in (60,62)
ORDER BY wait_time_ms DESC
GO

SELECT DB_NAME(database_id) AS Database_Name,
       OBJECT_NAME(ios.object_id,database_id) AS TableName,
	   i.name AS IndexName,i.index_id,
  	   ios.row_lock_count,
	   ios.row_lock_wait_count,
	   ios.row_lock_wait_in_ms,
	   ios.page_lock_count,
	   ios.page_lock_wait_count,
	   ios.page_lock_wait_in_ms,
	   ios.index_lock_promotion_attempt_count,
	   ios.index_lock_promotion_count,
	   ios.leaf_insert_count,
	   ios.leaf_update_count,
	   ios.leaf_delete_count + ios.leaf_ghost_count AS leaf_delete_count,
	   ios.page_latch_wait_count,
	   ios.page_latch_wait_in_ms
FROM sys.dm_db_index_operational_stats(DB_ID(),object_id('Person'),null,null) ios
INNER JOIN sys.indexes i on i.index_id = ios.index_id and i.object_id=ios.object_id;
GO

