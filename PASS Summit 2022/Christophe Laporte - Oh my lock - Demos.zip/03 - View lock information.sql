--==============================================================================
--
--  Summary:  PASS Summit 2022
--  Date:     11/2022
--
--  ----------------------------------------------------------------------------
--  Written by Christophe LAPORTE, SQL Server MVP / MCM
--	Twitter : @ConseilIT
--  
--  You may alter this code for your own *non-commercial* purposes. You may
--  republish altered code as long as you give due credit.
--  
--  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
--  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
--  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
--  PARTICULAR PURPOSE.
--==============================================================================
Use Pass2022
GO

-- informations about sessions involved in a locking scenario
SELECT es.session_id,es.host_name,es.program_name,es.login_name,
	   es.status,er.blocking_session_id,er.wait_type, er.wait_resource,
	   est.text
FROM sys.dm_exec_sessions es
LEFT JOIN sys.dm_exec_requests er on es.session_id = er.session_id
INNER JOIN sys.dm_exec_connections ec on es.session_id = ec.session_id
OUTER APPLY sys.dm_exec_sql_text(ec.most_recent_sql_handle) est
WHERE es.session_id IN (,)
GO

-- Deep dive into locked resources 

SELECT object_name(object_id) as TableName,*
FROM sys.partitions
where partition_id=72057594045726720


SELECT resource_type,db_name(resource_database_id) as DatabaseName,
		    CASE resource_type
			 WHEN 'KEY' THEN  
				( SELECT CONCAT('Table ',object_name(object_id),' / KeyHashValue ',SUBSTRING(resource_description,2,LEN(resource_description)-2))
					FROM sys.dm_db_partition_stats
					WHERE partition_id= resource_associated_entity_id
				)
			 WHEN 'PAGE' THEN  
				( SELECT CONCAT('Table ',object_name(object_id),' / Page ', SUBSTRING(resource_description,CHARINDEX(':',resource_description)+1,LEN(resource_description)))
					FROM sys.dm_db_partition_stats
					WHERE partition_id= resource_associated_entity_id
				)
			 WHEN 'DATABASE' THEN  
				( SELECT CONCAT('Database ',db_name(resource_database_id))
				)
			 ELSE CONCAT('Table ',object_name(resource_associated_entity_id))
        END	 as [Resource],
		resource_description,
        request_mode,request_type,request_status,request_session_id 
FROM sys.dm_tran_locks
WHERE request_session_id IN ()
ORDER BY request_session_id
GO




-- Crack the Data Page
DBCC TRACEON (3604)
DBCC PAGE (Pass2022,1,8096, 3)
GO


-- Use Adam Machanic stored procedure
-- https://github.com/amachanic/sp_whoisactive/releases
sp_whoisactive @show_sleeping_spids =1,
			@get_task_info=2,
			@get_additional_info =1,
			@get_full_inner_text = 1,	
			@get_outer_command = 1,
			@get_locks = 1,
			@find_block_leaders = 1,
			@get_plans = 1;
GO            


-- Retrieving information from Transaction Log
WITH cteTransaction AS (
	SELECT [Transaction ID] FROM sys.fn_dblog(NULL,NULL)
	WHERE [Transaction Name] = 'BlockingTransaction'
)
SELECT * 
FROM sys.fn_dblog(NULL,NULL) dblog
INNER JOIN cteTransaction on  cteTransaction.[Transaction ID] = dblog.[Transaction ID];
GO



-- Other queries provided by Microsoft
-- https://learn.microsoft.com/en-us/troubleshoot/sql/performance/understand-resolve-blocking

WITH cteBL (session_id, blocking_these) AS (
    SELECT s.session_id, blocking_these = x.blocking_these FROM sys.dm_exec_sessions s 
    CROSS APPLY    (SELECT isnull(convert(varchar(6), er.session_id),'') + ', '  
                    FROM sys.dm_exec_requests as er
                    WHERE er.blocking_session_id = isnull(s.session_id ,0)
                    AND er.blocking_session_id <> 0
                    FOR XML PATH('') ) AS x (blocking_these)
    )
SELECT s.session_id, blocked_by = r.blocking_session_id, bl.blocking_these,
       batch_text = t.text, input_buffer = ib.event_info, * 
FROM sys.dm_exec_sessions s 
LEFT OUTER JOIN sys.dm_exec_requests r on r.session_id = s.session_id
INNER JOIN cteBL as bl on s.session_id = bl.session_id
OUTER APPLY sys.dm_exec_sql_text (r.sql_handle) t
OUTER APPLY sys.dm_exec_input_buffer(s.session_id, NULL) AS ib
WHERE blocking_these is not null or r.blocking_session_id > 0
ORDER BY len(bl.blocking_these) desc, r.blocking_session_id desc, r.session_id;
GO


-- head of blocking chain
WITH cteHead ( session_id,request_id,wait_type,wait_resource,last_wait_type,is_user_process,request_cpu_time
,request_logical_reads,request_reads,request_writes,wait_time,blocking_session_id,memory_usage
,session_cpu_time,session_reads,session_writes,session_logical_reads
,percent_complete,est_completion_time,request_start_time,request_status,command
,plan_handle,sql_handle,statement_start_offset,statement_end_offset,most_recent_sql_handle
,session_status,group_id,query_hash,query_plan_hash) 
AS ( SELECT sess.session_id, req.request_id, LEFT (ISNULL (req.wait_type, ''), 50) AS 'wait_type'
    , LEFT (ISNULL (req.wait_resource, ''), 40) AS 'wait_resource', LEFT (req.last_wait_type, 50) AS 'last_wait_type'
    , sess.is_user_process, req.cpu_time AS 'request_cpu_time', req.logical_reads AS 'request_logical_reads'
    , req.reads AS 'request_reads', req.writes AS 'request_writes', req.wait_time, req.blocking_session_id,sess.memory_usage
    , sess.cpu_time AS 'session_cpu_time', sess.reads AS 'session_reads', sess.writes AS 'session_writes', sess.logical_reads AS 'session_logical_reads'
    , CONVERT (decimal(5,2), req.percent_complete) AS 'percent_complete', req.estimated_completion_time AS 'est_completion_time'
    , req.start_time AS 'request_start_time', LEFT (req.status, 15) AS 'request_status', req.command
    , req.plan_handle, req.[sql_handle], req.statement_start_offset, req.statement_end_offset, conn.most_recent_sql_handle
    , LEFT (sess.status, 15) AS 'session_status', sess.group_id, req.query_hash, req.query_plan_hash
    FROM sys.dm_exec_sessions AS sess
    LEFT OUTER JOIN sys.dm_exec_requests AS req ON sess.session_id = req.session_id
    LEFT OUTER JOIN sys.dm_exec_connections AS conn on conn.session_id = sess.session_id 
    )
, cteBlockingHierarchy (head_blocker_session_id, session_id, blocking_session_id, wait_type, wait_duration_ms,
wait_resource, statement_start_offset, statement_end_offset, plan_handle, sql_handle, most_recent_sql_handle, [Level])
AS ( SELECT head.session_id AS head_blocker_session_id, head.session_id AS session_id, head.blocking_session_id
    , head.wait_type, head.wait_time, head.wait_resource, head.statement_start_offset, head.statement_end_offset
    , head.plan_handle, head.sql_handle, head.most_recent_sql_handle, 0 AS [Level]
    FROM cteHead AS head
    WHERE (head.blocking_session_id IS NULL OR head.blocking_session_id = 0)
    AND head.session_id IN (SELECT DISTINCT blocking_session_id FROM cteHead WHERE blocking_session_id != 0)
    UNION ALL
    SELECT h.head_blocker_session_id, blocked.session_id, blocked.blocking_session_id, blocked.wait_type,
    blocked.wait_time, blocked.wait_resource, h.statement_start_offset, h.statement_end_offset,
    h.plan_handle, h.sql_handle, h.most_recent_sql_handle, [Level] + 1
    FROM cteHead AS blocked
    INNER JOIN cteBlockingHierarchy AS h ON h.session_id = blocked.blocking_session_id and h.session_id!=blocked.session_id --avoid infinite recursion for latch type of blocking
    WHERE h.wait_type COLLATE Latin1_General_BIN NOT IN ('EXCHANGE', 'CXPACKET') or h.wait_type is null
    )
SELECT bh.*, txt.text AS blocker_query_or_most_recent_query 
FROM cteBlockingHierarchy AS bh 
OUTER APPLY sys.dm_exec_sql_text (ISNULL ([sql_handle], most_recent_sql_handle)) AS txt;

