#==============================================================================
#
#  Summary:  PASS Summit 2022
#  Date:     11/2022
#
#  ----------------------------------------------------------------------------
#  Written by Christophe LAPORTE, SQL Server MVP / MCM
#  Twitter : @ConseilIT
#  
#  You may alter this code for your own *non-commercial* purposes. You may
#  republish altered code as long as you give due credit.
#  
#  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
#  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
#  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
#  PARTICULAR PURPOSE.
#==============================================================================


# Scripts based on dbaTools commands
# Thanks to Chrissy LeMaire (@cl | https://blog.netnerds.net/ )
#         , Rob Sewell (@SQLDBAWithBeard | https://sqldbawithabeard.com/)
#         , and all SQL Server community
# http://dbatools.io
# Install-Module dbatools 


Install-DbaWhoIsActive -SqlInstance "localhost\SQL2022" -Database master  | Out-Null

Restore-DbaDatabase -SqlInstance "localhost\SQL2022" -DatabaseName "WideWorldImporters" -Path "c:\backupDB\WideWorldImporters-Standard.bak"
Restore-DbaDatabase -SqlInstance "localhost\SQL2022" -DatabaseName "AdventureWorks2017" -Path "c:\backupDB\AdventureWorks2017.bak"

New-DbaDatabase -SqlInstance "localhost\SQL2022" -Name "Pass2022" -PrimaryFilesize 512 -LogSize 128

