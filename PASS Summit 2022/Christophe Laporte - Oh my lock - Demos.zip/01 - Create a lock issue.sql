--==============================================================================
--
--  Summary:  PASS Summit 2022
--  Date:     11/2022
--
--  ----------------------------------------------------------------------------
--  Written by Christophe LAPORTE, SQL Server MVP / MCM
--	Twitter : @ConseilIT
--  
--  You may alter this code for your own *non-commercial* purposes. You may
--  republish altered code as long as you give due credit.
--  
--  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
--  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
--  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
--  PARTICULAR PURPOSE.
--==============================================================================

USE  [Pass2022]
GO



DROP TABLE IF EXISTS [dbo].[Person];
GO

CREATE TABLE [dbo].[Person](
	[BusinessEntityID] [int] NOT NULL,
	[FirstName] [nvarchar](50) NOT NULL,
	[LastName] [nvarchar](50) NOT NULL,
	[Filler]  [char](100)
CONSTRAINT [PK_Person] PRIMARY KEY CLUSTERED 
	(
		[BusinessEntityID] ASC
	)
);
GO

INSERT INTO Person  (BusinessEntityID,FirstName,LastName)
SELECT BusinessEntityID,FirstName,LastName
FROM AdventureWorks2017.Person.Person
GO



-- Session #1 : Blocking session
USE  [Pass2022]
GO
PRINT CONCAT('Blocking session : ',@@SPID)
GO
BEGIN TRAN BlockingTransaction
	UPDATE Person
	SET Filler = 'Update from Session 1'
	WHERE BusinessEntityID = 1



-- Session #2 : Blocked session
USE  [Pass2022]
GO
PRINT CONCAT('Blocked session : ',@@SPID)
GO
SELECT * 
FROM Person
WHERE BusinessEntityID = 1;


