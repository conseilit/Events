
select * from sys.conversation_endpoints
select * from sys.dm_broker_activated_tasks 
select * from sys.dm_broker_connections 
select * from sys.dm_broker_forwarded_messages 
select * from sys.dm_broker_queue_monitors 
select * from sys.transmission_queue 
select * from sys.conversation_endpoints 
select * from sys.conversation_groups 
select * from sys.conversation_endpoints
select * from sys.remote_service_bindings
select * from sys.routes
select * from sys.service_contracts
select * from sys.service_contract_message_usages
select * from sys.service_contract_usages
select * from sys.service_message_types
select * from sys.services


