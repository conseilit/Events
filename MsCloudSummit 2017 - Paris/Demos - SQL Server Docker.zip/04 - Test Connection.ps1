<#============================================================================
  File:     
  Summary:  MsCloudSummit 2017 - Paris
  Date:     01/2017
  SQL Server Versions: 
------------------------------------------------------------------------------
  Written by Christophe LAPORTE, SQL Server MVP / MCM
	Blog    : http://conseilit.wordpress.com
	Twitter : @ConseilIT
  
  You may alter this code for your own *non-commercial* purposes. You may
  republish altered code as long as you give due credit.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================#>

# Container on Ubuntu Public Cloud
:CONNECT tcp:137.74.26.146,40001 -Usa -PPassword1!
select @@servername,@@version
GO


:CONNECT tcp:137.74.26.146,40001 -Usa -PPassword1!
CREATE DATABASE MsCloudSummit2017
GO

# Start-VM -Name Docker
# Get-VM -Name Docker | Select -ExpandProperty NetworkAdapters | Select VMName, IPAddresses, Status

:CONNECT tcp:xx,40001 -Usa -PPassword1!
select @@servername,@@version
GO


:CONNECT tcp:xx,40001 -Usa -PPassword1!
CREATE DATABASE MsCloudSummit2017
GO

