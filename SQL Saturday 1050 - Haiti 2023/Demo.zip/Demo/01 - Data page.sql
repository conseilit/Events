--============================================================================
--  
--  Written by Christophe LAPORTE, SQL Server MVP / MCM
--	Blog    : http://conseilit.wordpress.com
--	Twitter : @ConseilIT
--  
--  You may alter this code for your own *non-commercial* purposes. You may
--  republish altered code as long as you give due credit.
--  
--  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
--  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
--  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
--  PARTICULAR PURPOSE.
--
--============================================================================

USE [AdventureWorks2017]
GO

SELECT *
FROM [Production].[Product]
WHERE ProductID=715;













-- Find the data page
SELECT sys.fn_physLocFormatter (%%physloc%%) as RowLocator,*
FROM [Production].[Product]
WHERE ProductID=715;

-- Crack the Data Page
DBCC TRACEON(3604)
DBCC PAGE(0,1,16131,3)














-- Bonus

-- PFS Page
DBCC PAGE(0,1,1,3);

-- GAM Page
DBCC PAGE(0,1,2,3);

-- SGAM Page
DBCC PAGE(0,1,3,3);

-- Boot Page
DBCC PAGE(0,1,9,3);

-- Configuration Page
DBCC PAGE('master',1,10,3);

